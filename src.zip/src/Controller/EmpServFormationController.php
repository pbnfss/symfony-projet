<?php

namespace App\Controller;

use App\Entity\Formation;
use App\Entity\Produit;
use App\Form\CreateFormationType;
use PhpParser\Node\Expr\Cast\Object_;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


class EmpServFormationController extends AbstractController
{

    #[Route('/empServFormation', name: 'app_emp_serv_formation')]
    public function index(): Response
    {
        return $this->render('emp_serv_formation/index.html.twig', [
            'controller_name' => 'EmpServFormationController',
        ]);
    }
    #[Route('/createProduit', name: 'app_produit')]
    public function ajoutAction(ManagerRegistry $doctrine)
    {
        $user = new Produit();
        $user -> setLibelle("bureau");
        $entityManager = $doctrine->getManager();
        $entityManager->persist($user);
        $entityManager->flush();
        return $this->render('emplambda/index.html.twig',
            [
                'controller_name' => 'EmpServFormationController',
            ]);
    }

    #[Route('/empCreateFormation', name: 'app_emp_create_formation')]
    public function ajoutFormation(Request $request, ManagerRegistry $doctrine): Response
    {
        $formation = new Formation();
        $form = $this->createForm(CreateFormationType::class, $formation);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $doctrine->getManager();
            $entityManager->persist($formation);
            $entityManager->flush();

            return $this->redirectToRoute('app_emp_serv_formation');
        }

        return $this->render('emp_serv_formation/createFormation.html.twig', [
            'form' => $form->createView(),
        ]);
    }
}
