<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Formation;
use App\Entity\Produit;
use App\Form\CreateFormationType;
use PhpParser\Node\Expr\Cast\Object_;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Persistence\ManagerRegistry;

class EmplambdaController extends AbstractController
{
    #[Route('/emplambda', name: 'app_emplambda')]
    public function index(): Response
    {
        return $this->render('emplambda/index.html.twig', [
            'controller_name' => 'EmplambdaController',
        ]);
    }

    #[Route('/voirFormations', name: 'app_voir_les_formations')]
    public function listeFormations(Request $request, ManagerRegistry $doctrine)
    {
        // Récupérer les formations depuis la base de données
        $formations = $doctrine->getManager()->getRepository(Formation::class)->findAll();

        return $this -> render('emplambda/formations.html.twig', array('lesFormations' => $formations,));
    }

    /*#[Route('/inscription', name: 'app_voir_les_formations')]
    public function inscriptionFormation(Request $request, ManagerRegistry $doctrine)
    {
        $inscription = $doctrine->getManager()->getRepository(Formation::class)->findAll();

        return $this -> render('emplambda/formations.html.twig', array('lesFormations' => $formations));
    }*/

    
    /*#[Route("/liste-formations", name:"liste_formations")]
    public function listeFormations(Request $request, ManagerRegistry $doctrine)
    {
        // Récupérer les éléments de la table "formation" depuis la base de données
        $formations = $this->getDoctrine()->getRepository(Formation::class)->findAll();

        return $this->render('formation/liste_formations.html.twig', [
            'formations' => $formations,
        ]);
    }*/

}
